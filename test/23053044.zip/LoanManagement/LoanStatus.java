public enum LoanStatus {
  APPROVED,
  PENDING,
  REJECTED,
}
