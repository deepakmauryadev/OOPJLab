public class Customer {
  int customerId;
  String name;
  int age;
  double annualSalary;

  Customer(int customerId, String name, int age, double annualSalary) {
    this.customerId = customerId;
    this.name = name;
    this.age = age;
    this.annualSalary = annualSalary;
  }
}
